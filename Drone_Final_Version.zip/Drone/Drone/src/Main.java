import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
	
//    static private double scale = 0.0000200;
//    
//	//input 1: campus
//	static private double initialLat =  43.007979;  
//	static private double initialLong = -81.274686;
	
	//input2: wonderland
//	static private double initialLat =  42.985883;  
//	static private double initialLong = -81.298375;
	
	//input 3: hospital
//	static private double initialLat = 43.003320;
//	static private double initialLong = -81.274925;
	
	public static void main (String[] args)
	{
						
		/**
		 * Test ReadInput Class
		 */
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter an input file to open (without \".txt\"): ");
		String fileName = scanner.nextLine();
		ReadInput file = new ReadInput(fileName);
		
		// Track the running time of the program
		long startTime = System.currentTimeMillis();
		
		int xs = file.getStartX();
		int ys = file.getStartY();
		int xd = file.getDestinationX();
		int yd = file.getDestinationY();
		int wid = file.getAreaWidth();
		int len = file.getAreaLength();
		int w = file.getParameterW();
		int d = file.getParameterD();
		int num = file.getNumberOfObs();
		ArrayList<Integer> xList = file.getXList();
		ArrayList<Integer> yList = file.getYList();
		ArrayList<ArrayList<Integer>> xObsList = file.getXObsList();
		ArrayList<ArrayList<Integer>> yObsList = file.getYObsList();
		
    	
		/**
		 * Test DefineObstacles Class
		 */
    	System.out.println("\n==================== Test DefineObstacles Class ====================");
    	System.out.println("\n---------- Test ExpandRectangle Method ----------");
    	DefineObstacles rectangle = new DefineObstacles();
    	rectangle.ExpandRectangle(xObsList, yObsList, d);
    	    	
    	//System.out.println("\n\nThe number of elements in each xList is " + xListNew.size() + "\n");
		ArrayList<Integer> xListExpd = new ArrayList<Integer>();
		ArrayList<Integer> yListExpd = new ArrayList<Integer>();    	
    	ArrayList<ArrayList<Integer>> xObsListExpd = new ArrayList<ArrayList<Integer>>();
		ArrayList<ArrayList<Integer>> yObsListExpd = new ArrayList<ArrayList<Integer>>();
		
		xListExpd = rectangle.getXListExpd();
		yListExpd = rectangle.getYListExpd();		
		xObsListExpd = rectangle.getXObsListExpd();
		yObsListExpd = rectangle.getYObsListExpd();
    	
    	System.out.println("\nExpanded xObsList:");
    	for (int i = 0; i < xObsListExpd.size(); i++)
    	{
    		for (int j = 0; j < xListExpd.size(); j++)
    		{
    			System.out.print(xObsListExpd.get(i).get(j)+  " ");
    		}
    		System.out.println("");
    	}
    	
    	System.out.println("\nExpanded yObsList:");
    	for (int i = 0; i < yObsList.size(); i++)
    	{
    		for (int j = 0; j < yListExpd.size(); j++)
    		{
    			System.out.print(yObsListExpd.get(i).get(j)+  " ");
    		}
    		System.out.println("");
    	}
    	//System.out.println("The number of obstacles is " + yObsList.size() + "\n");
    	//System.out.println("The number of elements in each yList is " + yListExpd.size() + "\n");


    	System.out.println("\n\n---------- Test Sorting Method ----------");
    	rectangle.SortingX(xObsListExpd);
    	rectangle.SortingY(yObsListExpd);
    	
    	ArrayList<Integer> xListSorted = rectangle.getXListSorted();
    	ArrayList<Integer> yListSorted = rectangle.getYListSorted();
    	
    	ArrayList<Integer> xObsTagSorted = rectangle.getXObsTagSorted();
    	ArrayList<Integer> yObsTagSorted = rectangle.getYObsTagSorted();
    	
    	System.out.println("\nThe size of  xListSorted is: " + xListSorted.size());
    	System.out.println("Sorted x list:");
    	for (int i = 0; i < xListSorted.size(); i++)
    	{
    		System.out.print(xListSorted.get(i)+  " ");
    	}
    	   	
    	System.out.println("\n\nThe size of  xObsTagSorted is: " + xObsTagSorted.size());
    	System.out.println("Corresponding x tag list:");
    	for (int i = 0; i < xObsTagSorted.size(); i++)
    	{
    		System.out.print(xObsTagSorted.get(i)+  " ");
    	}
    	    	   	
    	System.out.println("\n\nThe size of  yListSorted is: " + yListSorted.size());
    	System.out.println("Sorted y list:");
    	for (int i = 0; i < yListSorted.size(); i++)
    	{
    		System.out.print(yListSorted.get(i)+  " ");
    	}  
    	
    	System.out.println("\n\nThe size of  yObsTagSorted is: " + yObsTagSorted.size());
    	System.out.println("Corresponding y tag list:");
    	for (int i = 0; i < yObsTagSorted.size(); i++)
    	{
    		System.out.print(yObsTagSorted.get(i)+  " ");
    	}
    	
    	
    	System.out.println("\n\n\n---------- Test RemoveRepetition Method ----------");
    	rectangle.removeRepetitionX(xListSorted);
    	rectangle.removeRepetitionY(yListSorted);
    	
    	ArrayList<Integer> xListSortedNoRepetition = rectangle.getXListSortedNoRepetition();
    	ArrayList<Integer> yListSortedNoRepetition = rectangle.getYListSortedNoRepetition();
       	
    	ArrayList<Integer> xObsTagSortedNoRepetition = rectangle.getXObsTagSortedNoRepetition ();
    	ArrayList<Integer> yObsTagSortedNoRepetition = rectangle.getYObsTagSortedNoRepetition ();
		
		System.out.println("\nThe size of xListSorted without repetition is: " + xListSortedNoRepetition.size());
		System.out.println("Sorted x list after removing repetitions:");
    	for (int k = 0; k < xListSortedNoRepetition.size(); k++)
		{
			System.out.print(xListSortedNoRepetition.get(k) + " ");
		}
    	
    	System.out.println("\n\nThe size of xObsTagSorted without repetition is: " + xObsTagSortedNoRepetition.size());
    	System.out.println("Corresponding x tag list after removing repetitions:");
    	for (int k = 0; k < xObsTagSortedNoRepetition.size(); k++)
		{
			System.out.print(xObsTagSortedNoRepetition.get(k) + " ");
		}
    	
		System.out.println("\n\nThe size of yListSorted without repetition is: " + yListSortedNoRepetition.size());
	 	System.out.println("Sorted y list after removing repetitions:");
		for (int k = 0; k < yListSortedNoRepetition.size(); k++)
		{
			System.out.print(yListSortedNoRepetition.get(k) + " ");
		}
		
    	System.out.println("\n\nThe size of yObsTagSorted without repetition is: " + yObsTagSortedNoRepetition.size());
		System.out.println("Corresponding y tag list after removing repetitions:");
    	for (int k = 0; k < yObsTagSortedNoRepetition.size(); k++)
		{
			System.out.print(yObsTagSortedNoRepetition.get(k) + " ");
		}
		
		
		System.out.println("\n\n\n---------- Test InsertElementsToSortedList Method ----------");
		int index_xs; 
		int index_ys; 
		int index_xd; 
		int index_yd;		

		index_xs = rectangle.addElementToSortedList(xListSortedNoRepetition, xObsTagSortedNoRepetition, xs);		
		index_ys = rectangle.addElementToSortedList(yListSortedNoRepetition, yObsTagSortedNoRepetition, ys);
		index_xd = rectangle.addElementToSortedList(xListSortedNoRepetition, xObsTagSortedNoRepetition, xd);
		index_yd = rectangle.addElementToSortedList(yListSortedNoRepetition, yObsTagSortedNoRepetition, yd);
		
		//System.out.println("Start and destination is " + index_xs + " " + index_ys + " " + index_xd + " " + index_yd);
		
		System.out.println("\nThe size of xListSorted without repetition after insert elements is: " + xListSortedNoRepetition.size());
		System.out.println("Sorted x list without repetition after insert elements:");
		for (int k = 0; k < xListSortedNoRepetition.size(); k++)
		{
			System.out.print(xListSortedNoRepetition.get(k) + " ");
		}
		
    	System.out.println("\n\nThe size of xObsTagSorted without repetition after insert elements is: " + xObsTagSortedNoRepetition.size());
    	System.out.println("Corresponding x tag list without repetition after insert elements:");
    	for (int k = 0; k < xObsTagSortedNoRepetition.size(); k++)
		{
			System.out.print(xObsTagSortedNoRepetition.get(k) + " ");
		}
		
		System.out.println("\n\nThe size of yListSorted without repetition after insert elements is: " + yListSortedNoRepetition.size());
		System.out.println("Sorted y list without repetition after insert elements:");
		for (int k = 0; k < yListSortedNoRepetition.size(); k++)
		{
			System.out.print(yListSortedNoRepetition.get(k) + " ");
		}
		
    	System.out.println("\n\nThe size of yObsTagSorted without repetition after insert elements is: " + yObsTagSortedNoRepetition.size());
    	System.out.println("Corresponding y tag list without repetition after insert elements:");
    	for (int k = 0; k < yObsTagSortedNoRepetition.size(); k++)
		{
			System.out.print(yObsTagSortedNoRepetition.get(k) + " ");
		}
    	
		
		
		/** 
		 *  Test CheckPointPosition class
		 */		
		//test checkPointValidation method
		System.out.println("\n\n\n\n==================== Test CheckPointPositoin Class ====================");
		System.out.println("\n---------- Test CheckPointValidation Method ----------");

		int[] tag = new int[num];
		CheckPointPosition check  = new CheckPointPosition();
		tag = check.checkPointValidation(xListSortedNoRepetition, yListSortedNoRepetition, xListSorted, yListSorted, xObsTagSorted, yObsTagSorted, num);
		System.out.println("\nThe size of tag list is: " + tag.length);
		System.out.println("The tagList: ");
		for (int x = 0; x < tag.length; x++)
		{
			System.out.print(tag[x] + " ");
		}

		
		System.out.println("\n\n\n---------- Test CheckPointPositoins Method ----------");		
		int[][] matrix = new int[yListSortedNoRepetition.size()][xListSortedNoRepetition.size()];
		
		//initialize the matrix
		for (int i = 0; i < yListSortedNoRepetition.size(); i++)
		{
			for (int j = 0; j < xListSortedNoRepetition.size(); j++)
			{
				matrix[i][j] = 0;
			}
		}
		
		System.out.println("\nInitialize the matrix:\n");
		for (int i = 0; i < yListSortedNoRepetition.size(); i++)
		{
			for (int j = 0; j < xListSortedNoRepetition.size(); j++)
			{
				System.out.format("%12d", matrix[i][j]);
			}
			System.out.print( "\n");
		}
		
		//if a position is invalid, mark it as negative infinity		
		for (int j = 0; j < yListSortedNoRepetition.size(); j++)
		{
			for (int i = 0; i < xListSortedNoRepetition.size(); i++)
			{
				
				matrix[j][i] = CheckPointPosition.CheckPointPositions(xListSortedNoRepetition.get(i), yListSortedNoRepetition.get(j), xObsListExpd, yObsListExpd, tag);
			}
		}
				
		System.out.println("\n\nMark the invalid positions as negative infinity:\n");		
		for (int i = 0; i < yListSortedNoRepetition.size(); i++)
		{
			for (int j = 0; j < xListSortedNoRepetition.size(); j++)
			{
				System.out.format("%12d", matrix[i][j]);
			}
			System.out.print( "\n");
		}
		
		
		
		/**
		 *  Test FindPath Class
		 */
		System.out.println("\n\n\n==================== Test FindPath Class ====================");
		System.out.println("\n---------- Test FindPath Method ----------");
		int[] xValue = new int[xListSortedNoRepetition.size()];
		int[] yValue = new int[yListSortedNoRepetition.size()];

		for (int i = 0; i < xListSortedNoRepetition.size(); i++)
		{			
			xValue[i] = xListSortedNoRepetition.get(i);
		}
		for (int i = 0; i < yListSortedNoRepetition.size(); i++)
		{			
			yValue[i] = yListSortedNoRepetition.get(i);
		}
		
		FindPath find = new FindPath();		
		FindPath.findPath( xValue, yValue, matrix, index_xs, index_ys, index_xd, index_yd,xObsTagSortedNoRepetition,yObsTagSortedNoRepetition, xObsListExpd, yObsListExpd );		
		
		ArrayList<Integer> xpath = new ArrayList<Integer>();
		ArrayList<Integer> ypath = new ArrayList<Integer>();
		
		xpath = find.getxPath();
		ypath = find.getyPath();
		
		int[] xPathValue = new int[xpath.size()];
		int[] yPathValue = new int[ypath.size()];
		
		//find the path value according to the x-y coordinate
		for (int i = ypath.size()-1; i >= 0; i--)
		{
			yPathValue[yPathValue.length-1-i] = yValue[ypath.get(i)];			
		}
		for (int i = xpath.size()-1; i >= 0; i--)
		{
			xPathValue[xPathValue.length-1-i] = xValue[xpath.get(i)];
		}
		
		//track the running time of finding the short path
		long endTime1 = System.currentTimeMillis();
		
		
		
		System.out.println("\n---------- Test FindShortestPath Method ----------");
		FindPath.findShorterPath(xValue, yValue, xpath, ypath, xObsListExpd, yObsListExpd, xListSorted, yListSorted, xObsTagSorted, yObsTagSorted, xListSortedNoRepetition, yListSortedNoRepetition,num);		
		
		ArrayList<Integer> xpathNew = new ArrayList<Integer>();
		ArrayList<Integer> ypathNew = new ArrayList<Integer>();
		
		xpathNew = find.getxPathNew(); 
		ypathNew = find.getyPathNew();
		
		int[] xPathValueNew = new int[xpathNew.size()];
		int[] yPathValueNew = new int[ypathNew.size()];
		
		for (int i = ypathNew.size()-1; i >= 0; i--)
		{
			yPathValueNew[i] = yValue[ypathNew.get(i)];			
		}
		for (int i = xpathNew.size()-1; i >= 0; i--)
		{
			xPathValueNew[i] = xValue[xpathNew.get(i)];
		}
		
		//Track the running time of the program (continue)
		long endTime2 = System.currentTimeMillis();
		
		
		/**
		 *  Display on the map
		 */
		System.out.println("\n\n==================== Display Paths on Map ====================\n");
    	int[] x1 = new int[xObsListExpd.size()];
    	int[] x2 = new int[xObsListExpd.size()];
    	int[] x3 = new int[xObsListExpd.size()];
    	int[] x4 = new int[xObsListExpd.size()];
    	
    	int[] y1 = new int[yObsListExpd.size()];
    	int[] y2 = new int[yObsListExpd.size()];
    	int[] y3 = new int[yObsListExpd.size()];
    	int[] y4 = new int[yObsListExpd.size()];
    	
    	for (int i = 0; i < xObsListExpd.size(); i++)
    	{   		
    		x1[i] = xObsListExpd.get(i).get(0);
    		x2[i] = xObsListExpd.get(i).get(1);
    		x3[i] = xObsListExpd.get(i).get(2);
    		x4[i] = xObsListExpd.get(i).get(3);  		
    	}
    	
    	for (int i = 0; i < yObsListExpd.size(); i++)
    	{   		
    		y1[i] = yObsListExpd.get(i).get(0);
    		y2[i] = yObsListExpd.get(i).get(1);
    		y3[i] = yObsListExpd.get(i).get(2);
    		y4[i] = yObsListExpd.get(i).get(3);  		
    	}

    	//ask the user to name the output file
    	Scanner user = new Scanner(System.in );
        System.out.println("Please name the output file(without \".html\"): ");
        String outputFileName = user.nextLine().trim();
        
        //display the original path
    	//DisplayMap display = new DisplayMap(outputFileName+ ".html", initialLat, initialLong, scale);
    	DisplayMap display = new DisplayMap(outputFileName+ ".html");
    	display.writeMap(xs, ys, xd, yd, xPathValue, yPathValue, x1, y1, x2, y2, x3, y3, x4, y4);
		
		//display shorter path
		//DisplayMap display1 = new DisplayMap(outputFileName+ "_shortest_path" + ".html", initialLat, initialLong, scale);
		DisplayMap display1 = new DisplayMap(outputFileName+ "_shortest_path" + ".html");
		display1.writeMap(xs, ys, xd, yd, xPathValueNew, yPathValueNew, x1, y1, x2, y2, x3, y3, x4, y4);
		
		
		System.out.println("\n\n\n==================== Statistics ====================");		
		System.out.println("\n---------- Input Data ----------\n");
		System.out.println("Starting Point: [" + xs + "," + ys + "]");
		System.out.println("Destination Point: [" + xd + "," + yd + "]");
		
		System.out.println("\n\n---------- Distances of Path ----------\n");		
		//1.Find the straight distance between starting point and destination point	
		int straight_distance = (int) Math.sqrt(Math.pow(xd-xs, 2) + Math.pow(yd-ys,2));
		System.out.println("Straight Distance: " + straight_distance);
		
		//2.Find the length of the short path
		System.out.println("Distance of Short Path: " + Math.abs(matrix[index_yd][index_xd]));
		
		//3.Find the distance of the shortest path
		int shortest_distance = 0;
		for (int i = 0; i < xPathValueNew.length-1; i++)
		{
			int currentX = xPathValueNew[i];
			int nextX = xPathValueNew[i+1];
			int currentY = yPathValueNew[i];
			int nextY = yPathValueNew[i+1];
			int temp = (int) Math.sqrt(Math.pow((nextX-currentX),2) + Math.pow(nextY-currentY, 2));
			shortest_distance += temp; 			
		}
		System.out.println("Distance of Shortest Path: " + shortest_distance);
		
		System.out.println("\n\n---------- Running Time ----------\n");
		//track the running time of the program
		long totalTime_shortPath = endTime1 - startTime;
		long totalTime_shortestPath = endTime2 - endTime1;
		System.out.println("Time of Finding Short Path: " + totalTime_shortPath + " milliseconds");
		System.out.println("Time of Finding the Shortest Path: " + totalTime_shortestPath + " milliseconds");
	}
}
