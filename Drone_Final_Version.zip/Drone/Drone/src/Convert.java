import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Convert 
{
	
	static private double scale = 0.0000200;
	
	//1.txt: campus
//	static private double initialLat =  43.007979;  
//	static private double initialLong = -81.274686;
	
	//2.txt: wonderland
//	static private double initialLat =  42.985883;  
//	static private double initialLong = -81.298375;
	
	//3.txt: hospital
//	static private double initialLat = 43.003320;
//	static private double initialLong = -81.274925;
	
	
	private int lineNum;
	private static double x_s;
    private static  double y_s;
    private double x_d;
    private double y_d;
    private int n;
    private ArrayList<Double> xList = null;
	private ArrayList<Double> yList = null;
	private ArrayList<ArrayList<Double>> xObsList = new ArrayList<ArrayList<Double>>();
    private ArrayList<ArrayList<Double>> yObsList = new ArrayList<ArrayList<Double>>();
    
	
    public double getStartX()
	{
		return x_s;
	}
	
	public double getStartY()
	{
		return y_s;
	}
	
	public double getDestinationX()
	{
		return x_d;
	}
	
	public double getDestinationY()
	{
		return y_d;
	}
	
	public int getN () 
	{
		return n;
	}
	
    public ArrayList<Double> getXList()
	{
		return xList;
	}
	
	public ArrayList<Double> getYList()
	{
		return yList;
	}
	
	public ArrayList<ArrayList<Double>> getXObsList()
	{
		return xObsList;
	}
	
	public ArrayList<ArrayList<Double>> getYObsList()
	{
		return yObsList;
	}

    public Convert (String fileName)
	{
        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fileName + ".txt");

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            switch(lineNum)
            {
	            case 0: //read starting point
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	x_s = Double.parseDouble(parts[0]);
	            	y_s = Double.parseDouble(parts[1]);
	            	//System.out.println("Starting point:\n(" + x_s + ","+ y_s + ")");
	            }
	            case 1: //read destination point
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	x_d = Double.parseDouble(parts[0]);
	            	y_d = Double.parseDouble(parts[1]);
	            	//System.out.println("Destination point:\n(" + x_d + ","+ y_d + ")");
	            }
	            case 2: //read number of obstacles
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	n = Integer.parseInt(parts[0]);
	            	//System.out.println("The width of flying area:\n" + width);
	            }
	            case 3: //read the coordinates of each obstacles
	            {	                
	            	while((line = bufferedReader.readLine()) != null) {
	            		xList =  new ArrayList<Double>();
	            		yList =  new ArrayList<Double>();
	                	String[] parts = line.split(",");

	                	 
	                	double x = 0, y = 0;
	                	for (int i = 0; i < parts.length; i++)
	                	{
	                		if (i%2 == 0)
	                		{
	                			//store x-coordinates of each obstacle in xList
	                			x = Double.parseDouble(parts[i]);
	                			xList.add(x);
	                		}
	                		else
	                		{
	                			//store y-coordinates of each obstacle in yList
	                			y = Double.parseDouble(parts[i]);
	                			yList.add(y);
	                		}	                	
	                	}
	                	
	                	//store each xList, yList in the xObsList, yObsList
		                xObsList.add(xList);
		                yObsList.add(yList);
	                } 	            	
	            }
            }      
            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println("Sorry, the file '" + fileName + "' doesn't exist.\nPlease check it carefully and try again.\nGood bye!");  
            System.exit(0);
        }
        catch(IOException ex) {
            System.out.println("Sorry, there is an error reading the file '" + fileName + "'.\nPlease check it carefully and try again.\nGood bye!"); 
            System.exit(0);
        }
	}
    
    
    //x_s: initialLat
    //y_s: initialLong
	public static int transferLon (double lon)
	{
		int x = (int) ((lon-y_s)/scale);
		return x;
	}
	
	public static int transferLat (double lat)
	{
		int y = (int)((lat-x_s)/scale);
		return y;
	}
	
	
    
    public static void main (String[] args)
    {
    	
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter an input file to open (without \".txt\"): ");
		String fileName = scanner.nextLine();
    	Convert cvt = new Convert (fileName);
    	System.out.println(transferLon(cvt.getStartY()) + "," + transferLat(cvt.getStartX()) + "\n" + transferLon(cvt.getDestinationY()) + "," + transferLat(cvt.getDestinationX()) );
    	for (int i = 0; i < cvt.getXObsList().size(); i++)
    	{
    		for (int j = 0; j < cvt.getXList().size(); j++)
    		{
    			System.out.print(transferLon(cvt.getYObsList().get(i).get(j)) +  "," + transferLat(cvt.getXObsList().get(i).get(j)) + ",");

    		}
    		System.out.println("");
    		
    	}
    	
    }
	
}
