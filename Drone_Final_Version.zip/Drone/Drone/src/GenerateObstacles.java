import java.io.File;
import java.io.IOException;
import java.util.Random;

public class GenerateObstacles {

	public static void main(String[] args) throws IOException {
		//delete a file if exist
//		File f = new File ("D:/All/Programming/Drone/Drone/generateObstacles.txt");
//		if (f.exists())
//		{
//			f.delete();
//		}
		int n = 80;
		while (n > 0)
		{
		//write files
		String file1 = "D:/All/Programming/Drone/Drone/random22.txt";
		WriteToFile data = new WriteToFile (file1, true);
		
		//generate first point of obstacles, i.e. A
		int min_point = 0;
		int max_point = 800;
		Random ran_point = new Random();
		int x_a = min_point + ran_point.nextInt(max_point);
		int y_a = min_point + ran_point.nextInt(max_point);
//		System.out.print("Point A(x,y)=(" + x_a + "," + y_a + ")");
//		data.writeToFile("Point A(x,y)=(" + x_a + "," + y_a + ")");
		
		//generate length and width
		int min_lw = 5;
		int max_lw = 50;
		Random ran_lw = new Random();
		int length = min_lw + ran_lw.nextInt(max_lw);
		int width = min_lw + ran_lw.nextInt(max_lw);
//		System.out.println("\nThe length is " + length + "\nThe width is " + width);
//		data.writeToFile("The length is " + length + "\nThe width is " + width);
		
		//generate the degree of rotation
		double min_angle = 0;
		double max_angle = Math.PI / 2;
		Random ran_angle = new Random();
		double angle = min_angle + ran_angle.nextDouble();
//		System.out.println("The degree of rotation is " + angle);
//		data.writeToFile("The degree of rotation is " + angle);
		//double angle = 0;
		
		//calculation of angle
		double cos_angle = Math.cos(angle);
		double sin_angle = Math.sin(angle);
//		System.out.println("cos(angle) is " + cos_angle + "\nsin(angle) is " + sin_angle);
//		data.writeToFile("cos(angle) is " + cos_angle + "\nsin(angle) is " + sin_angle);
		
		//calculation of a1, b1, a2, b2
		int a1 = (int)(length * cos_angle);
		int b1 = (int)(length * sin_angle);
		int a2 = (int)(width * cos_angle);
		int b2 = (int)(width * sin_angle);
//		System.out.println("a1 is " + a1 + "\nb1 is " + b1 + "\na2 is " + a2 + "\nb2 is " + b2);
//		data.writeToFile("a1 is " + a1 + "\nb1 is " + b1 + "\na2 is " + a2 + "\nb2 is " + b2);
		
		//calculat points B,C,D
		int x_b = x_a - a1;
		int y_b = y_a + b1;
		
		int x_c = x_a - a1 + b2;
		int y_c = y_a + b1 + a2;
		
		int x_d = x_a + b2;
		int y_d = y_a + a2;
		
//		System.out.println("xA,yA,xB,yB,xC,yC,xD,yD: \n" + x_a + "," + y_a + "," + x_b + ","  + y_b + "," + x_c + "," + y_c + "," + x_d + "," + y_d );
//		data.writeToFile("xA,yA,xB,yB,xC,yC,xD,yD: \n" + x_a + "," + y_a + "," + x_b + ","  + y_b + "," + x_c + "," + y_c + "," + x_d + "," + y_d );
		data.writeToFile(x_a + "," + y_a + "," + x_b + ","  + y_b + "," + x_c + "," + y_c + "," + x_d + "," + y_d );
//		}
//		catch (IOException e)
//		{
//			System.out.println(e.getMessage());
//		}
		
		
		//display on map
		int[] x1 = {x_a};
		int[] x2 = {x_b};
		int[] x3 = {x_c};
		int[] x4 = {x_d};
		
		int[] y1 = {y_a};
		int[] y2 = {y_b};
		int[] y3 = {y_c};
		int[] y4 = {y_d};
		
		DisplayMap m = new DisplayMap("random1.html");
		m.writeMapNoPath(0, 0, 1000, 1000, x1, y1, x2, y2, x3, y3, x4, y4); 
		n--;
		}
	}
	
}
