import java.util.ArrayList;


public class FindPath {
	
	/**
	 * instance variables
	 * xPath, yPath are used to store the values of the original path
	 * xPathNew, yPathNew are used to store the values of the shortest path
	 */
	static ArrayList<Integer> xPath = new ArrayList<Integer>();
	static ArrayList<Integer> yPath = new ArrayList<Integer>();	
	static ArrayList<Integer> xPathNew = new ArrayList<Integer>();
	static ArrayList<Integer> yPathNew = new ArrayList<Integer>();
	
	/**
	 * getters
	 * @return instance variables
	 */
	public ArrayList<Integer> getxPath()
	{
		return xPath;
	}
	
	public ArrayList<Integer> getyPath()
	{
		return yPath;
	}
		
	public ArrayList<Integer> getxPathNew()
	{
		return xPathNew;
	}

	public ArrayList<Integer> getyPathNew()
	{
		return yPathNew;
	}

	
	
	/**
	 * The Dijkstra's algorithm is implemented in this method.
	 * A matrix is used to represent the graph. 
	 * It starts from the starting point, i.e. i = y_s, j = x_s. 
	 * Each point in the matrix will check the validation of the 8 positions surrounding it.
	 * If any position surrounding this point is available, update the accumulated distance in corresponding position in the matrix
	 * Then it will go through the entire matrix and find the smallest number in the matrix.
	 * The algorithm will continue until it reaches the destination point, i.e. i = y_d, j = x_d.
	 * When update the matrix, another matrix (i.e. positon_matrix) will be used to track the trajectories of i and j. 
	 * Backtrack the position_matrix to find the path. 
	 * @param xValue all x coordinates of the obstacles
	 * @param yValue all y coordinates of the obstacles
	 * @param m the matrix with dimension of the length of y and x
	 * @param x_s x coordinate of the staring point
	 * @param y_s y coordinate of the starting point
	 * @param x_d x coordinate of the destination 
	 * @param y_d y coordinate of the destination
	 * @param xObsTagSortedNoRepetition tag of obstacles in the x list
	 * @param yObsTagSortedNoRepetition tag of obstacles in the y list
	 * @param xObsListExpd a list of lists of x coordinates of each obstacle
	 * @param yObsListExpd a list of lists of y coordinates of each obstacle
	 */
	public static void findPath(int[] xValue, int[] yValue, int[][] m,  int x_s, int y_s, int x_d, int y_d,  ArrayList<Integer> xObsTagSortedNoRepetition, ArrayList<Integer> yObsTagSortedNoRepetition, ArrayList<ArrayList<Integer>> xObsListExpd, ArrayList<ArrayList<Integer>> yObsListExpd)
	{		
		int[][] position = new int[yValue.length][xValue.length];
		
		for (int i = 0; i < yValue.length; i++)
		{
			for (int j = 0; j < xValue.length; j++)
			{
				//check if m[i][j] is blocked
				//if it is blocked, the value is equal to negative infinity				
				if(m[i][j] != -Integer.MIN_VALUE)
				{
					m[i][j] = Integer.MAX_VALUE;
				}	
			}
		}
		
		//initialize starting point to zero
		m[y_s][x_s] = 0;
						
		//start from the starting point
		int i = y_s, j = x_s;
		
		//while (i,j) is not the destination, find the smallest positive number in matrix
		//and jump to that position 
		while ( !(i == y_d && j == x_d) ) 
		{			
			//System.out.println("test 2: " + y_d + "," + x_d);
			int numSmall = Integer.MAX_VALUE;
			int row = 0 , col = 0;
			
			//point (i,j)
			ArrayList<Integer> tempTag = new ArrayList<Integer>();
			
			int tag1 = xObsTagSortedNoRepetition.get(j);
			if (tag1 != -1)
			{
				tempTag.add(tag1); 
			}
						
			if (j-1 >= 0)
			{
				int tag1_smaller = xObsTagSortedNoRepetition.get(j-1);
				if (tag1_smaller != -1 && tempTag.contains(tag1_smaller) == false)
				{
					tempTag.add(tag1_smaller);
				}
			}
			if (j+1 < xObsTagSortedNoRepetition.size())
			{
				int tag1_greater = xObsTagSortedNoRepetition.get(j+1);
				if (tag1_greater != -1 && tempTag.contains(tag1_greater) == false)
				{
					tempTag.add(tag1_greater);
				}
			}
			
			
			int tag2 = yObsTagSortedNoRepetition.get(i);
			if (tag2 != -1 && tempTag.contains(tag2) == false)
			{
				tempTag.add(tag2);
			}
			if (i-1 >= 0)
			{
				int tag2_smaller = yObsTagSortedNoRepetition.get(i-1);
				if (tag2_smaller != -1 && tempTag.contains(tag2_smaller) == false)
				{
					tempTag.add(tag2_smaller);
				}
			}
			if (i+1 < yObsTagSortedNoRepetition.size())
			{
				int tag2_greater = yObsTagSortedNoRepetition.get(i+1);
				if (tag2_greater  != -1 && tempTag.contains(tag2_greater) == false)
				{
					tempTag.add(tag2_greater );
				}
			}
			

		//case1: south-west
			if (i-1 >= 0 && j-1 >= 0 && m[i-1][j-1] > 0)
			{				
				if (tempTag.size() == 0)
				{
					int lsw = (int)Math.sqrt(Math.pow(yValue[i]-yValue[i-1], 2) + Math.pow((xValue[j]-xValue[j-1]), 2));
					if (Math.abs(m[i][j]) + lsw < m[i-1][j-1])
					{
						m[i-1][j-1] = Math.abs(m[i][j]) + lsw;	
						position[i-1][j-1] = 1;
					}
				}
				else 
				{
					//point (i-1, j-1)
					boolean cross = false; //assume not cross at first
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);
						
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);
						
						int x1 = xValue[j];
						int x2 = xValue[j-1];
						int y1 = yValue[i];
						int y2 = yValue[i-1];
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true;
							break;
						}						
					}
					if (cross == false)
					{
						int lsw = (int)Math.sqrt(Math.pow(yValue[i]-yValue[i-1], 2) + Math.pow((xValue[j]-xValue[j-1]), 2));
						if (Math.abs(m[i][j]) + lsw < m[i-1][j-1])
						{
							m[i-1][j-1] = Math.abs(m[i][j]) + lsw;	
							position[i-1][j-1] = 1;
						}
					}
				}
				
			}	
			
			//case2: west
			if (j-1 >= 0 && m[i][j-1] > 0)
			{				
				if (tempTag.size() == 0)
				{
					int lw = xValue[j] - xValue[j-1];
					if (Math.abs(m[i][j]) + lw < m[i][j-1])
					{
						m[i][j-1] = Math.abs(m[i][j]) + lw; 
						position[i][j-1] = 2;
					}
				}
				else
				{
					boolean cross = false; //assume not cross at first
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);
						
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);
						
						int x1 = xValue[j];
						int x2 = xValue[j-1];
						int y1 = yValue[i];
						int y2 = yValue[i];
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true; //now cross
							break;
						}
					}
					if (cross == false) 
					{
						int lw = xValue[j] - xValue[j-1];
						if (Math.abs(m[i][j]) + lw < m[i][j-1])
						{
							m[i][j-1] = Math.abs(m[i][j]) + lw; 
							position[i][j-1] = 2;
						}
					}
				}

			}
			
			//case3: north-west
			if (i+1 < yValue.length && j-1 >= 0 && m[i+1][j-1] > 0)
			{
				if (tempTag.size() == 0)
				{
					int lnw = (int)Math.sqrt(Math.pow(yValue[i+1]-yValue[i], 2) + Math.pow((xValue[j]-xValue[j-1]), 2));
					if (Math.abs(m[i][j]) + lnw < m[i+1][j-1])
					{
						m[i+1][j-1] = Math.abs(m[i][j]) + lnw; 
						position[i+1][j-1] = 3;
					}
				}
				else
				{
					boolean cross = false; // assume not cross at first
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);
						
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);
						
						int x1 = xValue[j];
						int x2 = xValue[j-1];
						int y1 = yValue[i];
						int y2 = yValue[i+1];
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true;
							break;
						}
					}
					if (cross == false)
					{
						int lnw = (int)Math.sqrt(Math.pow(yValue[i+1]-yValue[i], 2) + Math.pow((xValue[j]-xValue[j-1]), 2));
						if (Math.abs(m[i][j]) + lnw < m[i+1][j-1])
						{
							m[i+1][j-1] = Math.abs(m[i][j]) + lnw; 
							position[i+1][j-1] = 3;
						}
					}
				}

			}
			
			//case4: south
			if (i+1 < yValue.length && m[i+1][j] > 0)
			{
				if (tempTag.size() == 0)
				{
					int ln = yValue[i+1] - yValue[i];
					if (Math.abs(m[i][j]) + ln < m[i+1][j])
					{
						m[i+1][j] = Math.abs(m[i][j]) + ln; 
						position[i+1][j] = 4;
					}
				}
				else
				{
					//point (i+1, j)
					boolean cross = false;
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);					
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);				
						int x1 = xValue[j];
						int x2 = xValue[j];
						int y1 = yValue[i];
						int y2 = yValue[i+1];					
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true;
						}
					}
					if (cross == false)
					{
						int ln = yValue[i+1] - yValue[i];
						if (Math.abs(m[i][j]) + ln < m[i+1][j])
						{
							m[i+1][j] = Math.abs(m[i][j]) + ln; 
							position[i+1][j] = 4;
						}
					}
				}

			}

			//case5: 
			if(i+1 < yValue.length && j+1 < xValue.length && m[i+1][j+1] > 0 )
			{	
				if (tempTag.size() == 0)
				{
					int lne = (int)Math.sqrt(Math.pow(yValue[i+1]-yValue[i], 2) + Math.pow((xValue[j+1]-xValue[j]), 2));
					if (Math.abs(m[i][j]) + lne < m[i+1][j+1])
					{
						m[i+1][j+1] = Math.abs(m[i][j]) + lne; 
						position[i+1][j+1] = 5;
					}
				}
				else
				{
					//point (i+1, j+1)
					boolean cross = false;
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);
						
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);
						
						int x1 = xValue[j];
						int x2 = xValue[j+1];
						int y1 = yValue[i];
						int y2 = yValue[i+1];
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true;
							break;
						}
					}
					if (cross == false)
					{
						int lne = (int)Math.sqrt(Math.pow(yValue[i+1]-yValue[i], 2) + Math.pow((xValue[j+1]-xValue[j]), 2));
						if (Math.abs(m[i][j]) + lne < m[i+1][j+1])
						{
							m[i+1][j+1] = Math.abs(m[i][j]) + lne; 
							position[i+1][j+1] = 5;
						}
					}
				}

			}
			
			//case6: east  
			if (j+1 < xValue.length && m[i][j+1] > 0)
			{				
				if (tempTag.size() == 0)
				{
					int le = xValue[j+1] - xValue[j];
					if (Math.abs(m[i][j]) + le < m[i][j+1])
					{
						m[i][j+1] = Math.abs(m[i][j]) + le; 
						position[i][j+1] = 6;
					}
				}
				else
				{
					//point (i, j+1)
					boolean cross = false;
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);
						
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);
						
						int x1 = xValue[j];
						int y1 = yValue[i];
						int x2 = xValue[j+1];					
						int y2 = yValue[i];
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true;
							break;
						}

					}
					if (cross == false)
					{
						int le = xValue[j+1] - xValue[j];
						if (Math.abs(m[i][j]) + le < m[i][j+1])
						{
							m[i][j+1] = Math.abs(m[i][j]) + le; 
							position[i][j+1] = 6;
						}
					}
				}

			}
			
			//case7: north-east 
			if (i-1 >= 0 && j+1 < xValue.length && m[i-1][j+1] > 0)
			{				
				if (tempTag.size() == 0)
				{
					int lse = (int)Math.sqrt(Math.pow(yValue[i]-yValue[i-1], 2) + Math.pow((xValue[j+1]-xValue[j]), 2));
					if (Math.abs(m[i][j]) + lse < m[i-1][j+1])
					{
						m[i-1][j+1] = Math.abs(m[i][j])+ lse; 
						position[i-1][j+1] = 7;
					}
				}
				else
				{
					//point (i-1, j+1)
					boolean cross = false;
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);
						
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);
						
						int x1 = xValue[j];
						int x2 = xValue[j+1];
						int y1 = yValue[i];
						int y2 = yValue[i-1];
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true;
							break;
						}

					}
					if (cross == false)
					{
						int lse = (int)Math.sqrt(Math.pow(yValue[i]-yValue[i-1], 2) + Math.pow((xValue[j+1]-xValue[j]), 2));
						if (Math.abs(m[i][j]) + lse < m[i-1][j+1])
						{
							m[i-1][j+1] = Math.abs(m[i][j])+ lse; 
							position[i-1][j+1] = 7;
						}
					}
				}

			}
			
			//case8: north  
			if (i-1 >= 0 && m[i-1][j] > 0)
			{
				if (tempTag.size() == 0)
				{
					int ls = yValue[i] - yValue[i-1];
					if (Math.abs(m[i][j]) + ls < m[i-1][j])
					{
						m[i-1][j] = Math.abs(m[i][j]) + ls; 
						position[i-1][j] = 8;
					}
				}
				else
				{
					//point (i-1, j)
					boolean cross = false;
					for (int x = 0; x < tempTag.size(); x++)
					{
						int t = tempTag.get(x);
						int xA = xObsListExpd.get(t).get(0);
						int xB = xObsListExpd.get(t).get(1);
						int xC = xObsListExpd.get(t).get(2);
						int xD = xObsListExpd.get(t).get(3);
						
						int yA = yObsListExpd.get(t).get(0);
						int yB = yObsListExpd.get(t).get(1);
						int yC = yObsListExpd.get(t).get(2);
						int yD = yObsListExpd.get(t).get(3);
						
						int x1 = xValue[j];
						int x2 = xValue[j];
						int y1 = yValue[i];
						int y2 = yValue[i-1];
						
						//return true if cross
						if (checkLineCrossObstacles(x1, y1, x2, y2, xA, xB, xC, xD, yA, yB, yC, yD) == true)
						{
							cross = true;
							break;
						}
					}
					if (cross == false)
					{
						int ls = yValue[i] - yValue[i-1];
						if (Math.abs(m[i][j]) + ls < m[i-1][j])
						{
							m[i-1][j] = Math.abs(m[i][j]) + ls; 
							position[i-1][j] = 8;
						}
					}
				}
				
			}
			
//			System.out.println("\n\nnew matrix");
//			for (i = 0; i < yValue.length; i++)
//			{
//				for (j = 0; j < xValue.length; j++)
//				{			
//					System.out.printf("%12d",m[i][j]);								
//				}
//				System.out.print("\n");
//			}
			
			//find the smallest number in matrix
			for (row = 0; row < yValue.length; row++)
			{
				for (col = 0; col < xValue.length; col++)
				{					
					if (m[row][col] > 0 && m[row][col] < numSmall)
					{
						numSmall = m[row][col];	
						i = row;
						j = col;
					}					
				}
			}
			
			//mark it as negative number if this position has been visited
			m[i][j] *= -1;
					
		}
		
		//store the shortest path in xPath, yPath	
		//add the destination point
		xPath.add(x_d);
		yPath.add(y_d);
		
		//find the shortest path
		int p = x_d, q = y_d ;	
		
		//print matrix after Dijkstra's algorithm is applied
		System.out.println("\nMatrix after Dijkstra's algorithm is applied:\n");
		for (int w = 0; w < yValue.length; w++)
		{
			for (int v = 0; v < xValue.length; v++)
			{			
				System.out.format("%12d", m[w][v]);								
			}
			System.out.println("");
		}
		
		//print the position matrix
		System.out.println("\n\nPosition matrix to do backtrack:\n");
		for (int v = 0; v < yValue.length; v++)
		{
			for (int w = 0; w < xValue.length; w++)
			{			
				System.out.format("%12d" , position[v][w]);								
			}
			System.out.println("");
		}
		

		/*
		 * Notation for record the position
		 * 1: south west
		 * 2: west
		 * 3: north west
		 * 4: north
		 * 5: north east
		 * 6: east
		 * 7: south east
		 * 8: south
		 */
		while (!(p == x_s && q == y_s))
		{
			if (position[q][p] == 1)
			{
				q = q + 1;
				p = p + 1;
				xPath.add(p);
				yPath.add(q);				
			}
			else if (position[q][p] == 2)
			{
				p = p + 1;
				xPath.add(p);
				yPath.add(q);
			}
			else if (position[q][p] == 3)
			{
				q = q - 1;
				p = p + 1;
				xPath.add(p);
				yPath.add(q);
			}
			else if (position[q][p] == 4)
			{
				q = q - 1;
				xPath.add(p);
				yPath.add(q);
			}
			else if (position[q][p] == 5)
			{
				q = q - 1;
				p = p - 1;
				xPath.add(p);
				yPath.add(q);
			}
			else if (position[q][p] == 6)
			{
				p = p - 1;
				xPath.add(p);
				yPath.add(q);
			}
			else if (position[q][p] == 7)
			{
				q = q + 1;
				p = p - 1;
				xPath.add(p);
				yPath.add(q);
			}
			else if (position[q][p] == 8)
			{
				q = q + 1;
				xPath.add(p);
				yPath.add(q);
			}
		}
		

		System.out.println("\n\nX-Y Path:");
		for (i = xPath.size()-1; i >= 0; i--)
		{
			System.out.print("(" + yPath.get(i) + "," + xPath.get(i) + ")" + "\n");
			//System.out.print("(" + xPath.getElement(i) + "," + yPath.getElement(i) + ") " + m[xPath.getElement(i)][yPath.getElement(i)] + "\n");
		}
		System.out.println(" ");
	}

	
	/**
	 * Check if a line segment crosses a rectangle
	 * @param x1 value x of first point
	 * @param y1 value y of first point
	 * @param x2 value x of second point
	 * @param y2 value y of second point
	 * @param xA value x of corner A 
	 * @param xB value x of corner B 
	 * @param xC value x of corner C 
	 * @param xD value x of corner D 
	 * @param yA value y of corner A 
	 * @param yB value y of corner B 
	 * @param yC value y of corner C 
	 * @param yD value y of corner D 
	 * @return true if it crosses, otherwise return false
	 */
	public static boolean checkLineCrossObstacles(int x1, int y1, int x2, int y2, int xA, int xB, int xC, int xD, int yA, int yB, int yC, int yD)
	{
		//2 cases of the rectangles
		//case 1: parallel 	
		if (xB == xC && xA == xD && yA == yB && yC == yD)
		{
			//x1, x2 in the same region, and outside rectangle
			if (Integer.max(x1,x2) <= xB || Integer.min(x1, x2)>= xD || Integer.max(y1, y2) <= yA || Integer.min(y1, y2) >= yC)				
			{
				//not cross
				return false;
			}
			else
			{

				//case 1: line AB 
				double tempx1 = findIntersectionX(x1, y1, x2, y2, xA, yA, xB, yB);
				double tempy1 = findIntersectionY(x1, y1, x2, y2, xA, yA, xB, yB);
				if (tempx1 <= xA && tempx1 >= xB && tempy1 >= yA && tempy1 <= yB)
				{
					return true;
				}
				else 
				{
					//line BC
					double tempx2 = findIntersectionX(x1, y1, x2, y2, xB, yB, xC, yC);
					double tempy2 = findIntersectionY(x1, y1, x2, y2, xB, yB, xC, yC);
					if (tempx2 >= xB && tempx2 <= xC && tempy2 >= yB && tempy2 <= yC)
					{
						return true;
					}
					else
					{
						//line CD
						double tempx3 = findIntersectionX(x1, y1, x2, y2, xC, yC, xD, yD);
						double tempy3 = findIntersectionY(x1, y1, x2, y2, xC, yC, xD, yD);
						if (tempx3 >= xC && tempx3 <= xD && tempy3 >= yD && tempy3 <= yC)
						{
							return true;
						}
						else
						{
							//line DA
							double tempx4 = findIntersectionX(x1, y1, x2, y2, xD, yD, xA, yA);
							double tempy4 = findIntersectionY(x1, y1, x2, y2, xD, yD, xA, yA);
							if (tempx4 <= xD && tempx4 >= xA && tempy4 >= yA && tempy4 <= yD)
							{
								return true;
							}
							else
							{
								return false;
							}
						}
					}
				}
			
			}			
		}
		//case 2: not parallel 
		else 
		{
			//x1,x2 both in the same region, and outside rectangle
			if (Integer.max(x1,x2) <= xB || Integer.min(x1, x2)>= xD || Integer.max(y1, y2) <= yA || Integer.min(y1, y2) >= yC)				
			{
				//not cross
				return false;
			}
			else
			{
				//case 1: line AB 
				double tempx1 = findIntersectionX(x1, y1, x2, y2, xA, yA, xB, yB);
				double tempy1 = findIntersectionY(x1, y1, x2, y2, xA, yA, xB, yB);
				if (tempx1 < xA && tempx1 > xB && tempy1 > yA && tempy1 < yB)
				{
					return true;
				}
				else 
				{
					//line BC
					double tempx2 = findIntersectionX(x1, y1, x2, y2, xB, yB, xC, yC);
					double tempy2 = findIntersectionY(x1, y1, x2, y2, xB, yB, xC, yC);
					if (tempx2 > xB && tempx2 < xC && tempy2 > yB && tempy2 < yC)
					{
						return true;
					}
					else
					{
						//line CD
						double tempx3 = findIntersectionX(x1, y1, x2, y2, xC, yC, xD, yD);
						double tempy3 = findIntersectionY(x1, y1, x2, y2, xC, yC, xD, yD);
						if (tempx3 > xC && tempx3 < xD && tempy3 > yD && tempy3 < yC)
						{
							return true;
						}
						else
						{
							//line DA
							double tempx4 = findIntersectionX(x1, y1, x2, y2, xD, yD, xA, yA);
							double tempy4 = findIntersectionY(x1, y1, x2, y2, xD, yD, xA, yA);
							if (tempx4 < xD && tempx4 > xA && tempy4 > yA && tempy4 < yD)
							{
								return true;
							}
							else
							{
								return false;
							}
						}
					}
				}
			}
		}
	}	
	
	
	/**
	 * find x coordinate of the intersection point given two line segments
	 * @param x1 x coordinate of first point
	 * @param y1 y coordinate of first point
	 * @param x2 x coordinate of second point
	 * @param y2 y coordinate of second point
	 * @param x3 x coordinate of third point
	 * @param y3 y coordinate of third point
	 * @param x4 x coordinate of forth point
	 * @param y4 y coordinate of forth point
	 * @return x coordinate of the intersection
	 */
	public static double findIntersectionX(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
	{
		double x = 0;
		try
		{
			x  = (((double)x2*y1-x1*y2)*(x3-x4)+(x4*y3-x3*y4)*(x2-x1))/((y2-y1)*(x4-x3)-(y4-y3)*(x2-x1));
		}
		catch(Exception e)
		{
			//System.out.println("division by zero exception");
		}		
		return x;
	}
	
	
	/**
	 * find y coordinate of the intersection point given two line segments
	 * @param x1 x coordinate of first point
	 * @param y1 y coordinate of first point
	 * @param x2 x coordinate of second point
	 * @param y2 y coordinate of second point
	 * @param x3 x coordinate of third point
	 * @param y3 y coordinate of third point
	 * @param x4 x coordinate of forth point
	 * @param y4 y coordinate of forth point
	 * @return y coordinate of the intersection
	 */
	public static double findIntersectionY(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
	{
		double y = 0;
		try
		{
			y = (((double)x3*y4-x4*y3)*(y2-y1)+(x2*y1-x1*y2)*(y4-y3))/((x2-x1)*(y4-y3)-(x4-x3)*(y2-y1));
		}
		catch (Exception e)
		{
			//System.out.println("division by zero exception");
		}
		
		return y;
	}
		
	
	/**
	 * Given a path, find a shorter path. 
	 * @param xValue 
	 * @param yValue
	 * @param xObsList
	 * @param yObsList
	 * @param xListSorted
	 * @param yListSorted
	 * @param xTagListSorted
	 * @param yTagListSorted
	 * @param xListSortedNoRepeat
	 * @param yListSortedNoRepeat
	 */
	public static void findShorterPath (int[] xValue, int[] yValue,  ArrayList<Integer> xpath, ArrayList<Integer> ypath, ArrayList<ArrayList<Integer>> xObsList, ArrayList<ArrayList<Integer>> yObsList, ArrayList<Integer> xListSorted, ArrayList<Integer> yListSorted, ArrayList<Integer> xTagListSorted, ArrayList<Integer> yTagListSorted, ArrayList<Integer> xListSortedNoRepeat, ArrayList<Integer> yListSortedNoRepeat, int obsNum)
	{		
		int i = xpath.size()-1;
		ArrayList<Integer> xpath_temp = new ArrayList<Integer>();
		ArrayList<Integer> ypath_temp = new ArrayList<Integer>();
		xpath_temp.add(xpath.get(i));
		ypath_temp.add(ypath.get(i));
	
		while (i >= 2)
		{					
			int[] tagList = new int[obsNum];
			
			int currentRow = ypath.get(i);  //row is  yValue
			int currentCol = xpath.get(i);  //col is xValue
			int nextNextRow = ypath.get(i-2);
			int nextNextCol = xpath.get(i-2);
			
			//find x and y values
			int currentX = xValue[currentCol];
			int currentY = yValue[currentRow]; 
			int nextNextX = xValue[nextNextCol];
			int nextNextY = yValue[nextNextRow]; 
			
			//find a smaller value than currentX
			//find a greater value than currentX
			int smallerCurrentX = findSmallerValue (currentX, xListSortedNoRepeat);		
			int greaterCurrentX = findGreaterValue(currentX, xListSortedNoRepeat);
			
			//find a smaller value than currentY
			//find a greater value than currentY
			int smallerCurrentY = findSmallerValue (currentY, yListSortedNoRepeat);		
			int greaterCurrentY = findGreaterValue(currentY, yListSortedNoRepeat);
			
			//find a smaller value than nextNextX
			//find a greater value than nextNextX
			int smallerNextNextX = findSmallerValue (nextNextX, xListSortedNoRepeat);		
			int greaterNextNextX = findGreaterValue(nextNextX, xListSortedNoRepeat);
			
			//find a smaller value than nextNextY
			//find a greater value than nextNextY
			int smallerNextNextY = findSmallerValue (nextNextY, yListSortedNoRepeat);		
			int greaterNextNextY = findGreaterValue(nextNextY, yListSortedNoRepeat);
			
			for (int m = 0; m < xListSorted.size(); m++)
			{
				if ( xListSorted.get(m).equals(currentX) || xListSorted.get(m).equals(smallerCurrentX) || xListSorted.get(m).equals(greaterCurrentX) || xListSorted.get(m).equals(nextNextX) || xListSorted.get(m).equals(smallerNextNextX) || xListSorted.get(m).equals(greaterNextNextX))
				{
					int tag = xTagListSorted.get(m);
					if (tagList[tag] == 0)  
					{
						tagList[tag] = 1;
					}
				}
			}
			for (int m = 0; m < yListSorted.size(); m++)
			{
				if ( yListSorted.get(m).equals(currentY) || yListSorted.get(m).equals(smallerCurrentY) || yListSorted.get(m).equals(greaterCurrentY) || yListSorted.get(m).equals(nextNextY) || yListSorted.get(m).equals(smallerNextNextY) || yListSorted.get(m).equals(greaterNextNextY))
				{
					int tag = yTagListSorted.get(m);
					if (tagList[tag] == 0)  
					{
						tagList[tag] = 1;
					}
				}
			}
			
			for (int h = 0; h < tagList.length; h++)
			{
				tagList[h] = 1;
			}
					
			//check if cross
			//i represents the ith obstacles 
			boolean cross = false;  //not cross
			for (int m = 0; m < tagList.length; m++)
			{
				if (tagList[m] == 1)
				{
					int tag = m;
					int xA = xObsList.get(tag).get(0);
					int xB = xObsList.get(tag).get(1);
					int xC = xObsList.get(tag).get(2);
					int xD = xObsList.get(tag).get(3);
					
					int yA = yObsList.get(tag).get(0);
					int yB = yObsList.get(tag).get(1);
					int yC = yObsList.get(tag).get(2);
					int yD = yObsList.get(tag).get(3);
					
					boolean result = checkLineCrossObstacles(currentX, currentY, nextNextX, nextNextY, xA, xB, xC, xD, yA, yB, yC, yD);
					if (result == true)  //true means cross
					{
						cross = true;
						i = i - 1;
						xpath_temp.add(xpath.get(i));
						ypath_temp.add(ypath.get(i));						
						break;
					}
				}
			}
			if (cross == false)  //false means not cross
			{
				xpath_temp.add(nextNextCol);
				ypath_temp.add(nextNextRow); 
				i = i - 2;
			}
		}
		
		//if the last point is not the starting point, add starting point to the path
		if (!(xpath_temp.get(xpath_temp.size()-1) == xpath.get(0) && ypath_temp.get(ypath_temp.size()-1) == ypath.get(0)) )
		{
			xpath_temp.add(xpath.get(0));
			ypath_temp.add(ypath.get(0));
		}
		
		if (xpath_temp.size() == xpath.size())
		{
			
			for (int m = 0; m < xpath_temp.size(); m++)
			{
				xPathNew.add(xpath_temp.get(m));
			}
			for (int m = 0; m < ypath_temp.size(); m++)
			{
				yPathNew.add(ypath_temp.get(m));
			}
			//print the new path
			System.out.println("\nNew X-Y Path:");
			for (int m = 0; m < xPathNew.size(); m++)
			{
				System.out.print("(" + yPathNew.get(m) + "," + xPathNew.get(m) + ")" + "\n");
				//System.out.print("(" + xPath.getElement(i) + "," + yPath.getElement(i) + ") " + m[xPath.getElement(i)][yPath.getElement(i)] + "\n");
			}
			System.out.println(" ");			
		}
		else
		{

			findShorterPath (xValue, yValue,  xpath_temp, ypath_temp, xObsList, yObsList, xListSorted, yListSorted, xTagListSorted, yTagListSorted, xListSortedNoRepeat, yListSortedNoRepeat, obsNum);
		}
		

	}
	
	
	/**
	 * find smaller values
	 * @param value
	 * @param sortedList
	 * @return
	 */
	public static int findSmallerValue (int value, ArrayList<Integer> sortedList)
	{
		int smaller = -1;
		for (int i = 0; i < sortedList.size(); i++)
		{
			if (sortedList.get(i).equals(value) && i-1 >= 0)
			{
				smaller = sortedList.get(i-1);
				break;
			}			
		}
		return smaller;
	}
	
	
	/**
	 * find greater values
	 * @param value
	 * @param sortedList
	 * @return
	 */
	public static int findGreaterValue (int value, ArrayList<Integer> sortedList)
	{
		int greater = -1;
		for (int i = 0; i < sortedList.size(); i++)
		{
			if (sortedList.get(i).equals(value) && i+1 < sortedList.size())
			{
				greater = sortedList.get(i+1);
				break;
			}			
		}
		return greater;
	}
	
}
