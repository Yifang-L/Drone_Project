import java.util.ArrayList;

public class CheckPointPosition {
	
	/**
	 * the length of tagList is the number of obstacles in total
	 * the index i of tagList represent the ith obstacles
	 * tagList is initialized to be zero, which means no obstacle needs to be checked
	 * tagList[i] will be set to 1, if the ith obstacle needs to be checked
	 */
	static int[] tagList; 
	
	/**
	 * Find the obstacles which are above, below, on the left and on the right of a given point
	 * Get the tag of these obstacles and mark them as 1 in the tagList
	 * Given a point (x,y) 
	 * Find the previous smaller value of x and next greater value of x in the sorted x list
	 * Find the previous smaller value of y and next greater value of y in the sorted y list
	 * Find all tags (obstacles) corresponding to x-smaller, x-greater, y-smaller and y-greater values
	 * Mark the tags corresponding to the found obstacles as 1 in tagList
	 * @param xListSortedNoRepetition all x values without repetition sorted from smallest to largest 
	 * @param yListSortedNoRepetition all y values without repetition sorted from smallest to largest
	 * @param xListSorted all x values with repetition sorted from smallest to largest
	 * @param yListSorted all y values with repetition sorted from smallest to largest
	 * @param xTagListSorted the tag values corresponding to xListSorted
	 * @param yTagListSorted the tag values corresponding to yListSorted
	 * @param obsNum the number of obstacles in total
	 * @return the tagList
	 */
	public int[] checkPointValidation(ArrayList<Integer> xListSortedNoRepetition, ArrayList<Integer> yListSortedNoRepetition, ArrayList<Integer> xListSorted, ArrayList<Integer> yListSorted, ArrayList<Integer> xTagListSorted, ArrayList<Integer> yTagListSorted, int obsNum)
	{		
		tagList = new int[obsNum];
		for (int i = 0; i < yListSortedNoRepetition.size(); i++)
		{
			for (int j = 0; j < xListSortedNoRepetition.size(); j++)
			{
				//case1: west
				//find the obstacle on the left of the given point
				if (j-1 >= 0)
				{
					int temp = xListSortedNoRepetition.get(j-1);
					for (int k = 0; k < xListSorted.size(); k++)
					{
						if(temp == xListSorted.get(k))
						{
							int tag = xTagListSorted.get(k);
							if (tagList[tag] == 0)  
							{
								tagList[tag] = 1;
							}
						}
					}
				}
				
				//case 2: south
				//find the obstacle below the given point
				if (i-1 >= 0)
				{
					int temp = yListSortedNoRepetition.get(i-1);
					for (int k = 0; k < yListSorted.size(); k++)
					{
						if (temp == yListSorted.get(k))
						{
							int tag = yTagListSorted.get(k);
							if (tagList[tag] == 0)  
							{
								tagList[tag] = 1;
							}							
						}
					}
				}
				
				//case 3: east	
				//find the obstacle on the right of the given point
				if (j+1 < xListSortedNoRepetition.size())
				{
					int temp = xListSortedNoRepetition.get(j+1);
					for (int k = 0; k < xListSorted.size(); k++)
					{						
						if(temp == xListSorted.get(k))
						{							
							int tag = xTagListSorted.get(k);
							if (tagList[tag] == 0)  
							{
								tagList[tag] = 1;
							}
						}
					}
				}
				
				//case 4: north	
				//find the obstacle above the given point
				if ( i+1 < yListSortedNoRepetition.size())
				{
					int temp = yListSortedNoRepetition.get(i+1);
					for (int k = 0; k < yListSorted.size(); k++)
					{
						if (temp == yListSorted.get(k) )
						{
							int tag = yTagListSorted.get(k);
							if (tagList[tag] == 0)  
							{
								tagList[tag] = 1;
							}
						}
					}
				}
				
				//print the ansTagList
//				System.out.println("Im the tag list" );
//				for (int m = 0; m < tagList.length; m++)
//				{
//					System.out.print(tagList[m] + ", ");
//				}
//				System.out.println("\n");				
			}
		}
		return tagList;
	}
	
	
	/**
	 * Given a position (x,y), check if it is inside an obstacle
	 * If yes, mark this position as invalid, which means we are not allowed to move to this position
	 * Otherwise, mark this position as valid, which means this position is available to move to
	 * @param x coordinate x of the given position
	 * @param y coordinate y of the given position
	 * @param xObsList the list which stores the list of x values for each obstacle
	 * @param yObsList the list which stores the list of y values for each obstacle
	 * @param tagList a tag list used to record which obstacles need to be checked
	 * 		  if tagList[i] = 0, don't check ith obstacle, otherwise check ith obstacle
	 * @return 0 if the position (x,y) is valid, otherwise return Integer.MIN_VALUE
	 */
	public static int CheckPointPositions(int x, int y, ArrayList<ArrayList<Integer>> xObsList, ArrayList<ArrayList<Integer>> yObsList, int[] tagList)
	{		
		int valid = 0;
		int i = 0;

		while (i < tagList.length && tagList[i] != 0) 
		{
			//get the coordinates of the obstacle
			int tag = i;
			int xA = xObsList.get(tag).get(0);
			int xB = xObsList.get(tag).get(1);
			int xC = xObsList.get(tag).get(2);
			int xD = xObsList.get(tag).get(3);
			
			int yA = yObsList.get(tag).get(0);
			int yB = yObsList.get(tag).get(1);
			int yC = yObsList.get(tag).get(2);
			int yD = yObsList.get(tag).get(3);
			
			if (x <= xB || x >= xD || y <= yA || y >= yC)
			{
				//(x,y) is outside rectangle
				i++;
			}
			else if (xB == xC && yA == yB)		//rectangle is parallel	  
			{
				//(x,y) is inside 
				return Integer.MIN_VALUE;
			}
			else //(x,y) may or may not inside 
			{
				if (x <= Math.min(xA, xC))  //left part
				{
					double y1 = ((double)(x-xB))*(yA-yB)/(xA-xB) + yB;   //line AB
					double y2 = ((double)(x-xC))*(yB-yC)/(xB-xC) + yC;	//line BC
					
					if ((double)y <= y1)
					{
						//outside
						i++;
					}
					else if ((double)y >= y2)
					{
						//outside
						i++;
					}
					else
					{ 
						//inside
						return Integer.MIN_VALUE;
					}
					
				}
				else if (x >= Math.max(xA, xC))  //right part
				{
					double y3 = ((double)(x-xD))*(yC-yD)/(xC-xD) + yD;	//line CD
					double y4 = ((double)(x-xD))*(yA-yD)/(xA-xD) + yD;	//line AD
					
					if ((double)y <= y4)
					{
						//outside
						i++;
					}
					else if ((double)y >= y3)
					{
						//outside
						i++;
					}
					else
					{ 
						return Integer.MIN_VALUE;
					}
				}
				else if ( x > Math.min(xA, xC) && x < Math.max(xA, xC)) //middle part
				{
					double y5 =((double)(x-xB))*(yA-yB)/(xA-xB) + yB; //line AB,
					double y6 = ((double)(x-xD))*(yC-yD)/(xC-xD) + yD;  //line CD
					
					if ((double)y <= y5)
					{
						//outside
						i++; 
					}
					else if ((double)y >= y6)
					{
						//outside
						i++;
					}
					else 
					{
						return Integer.MIN_VALUE;
					}
				}
			}
		}
		return valid;		
	}

}
