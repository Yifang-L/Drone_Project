//https://www.homeandlearn.co.uk/java/write_to_textfile.html

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class WriteToFile 
{
	private String path;
	private boolean append_to_file = false;
	
	//constructor
	public WriteToFile (String file_path)
	{
		path = file_path;
	}
	
	public WriteToFile (String file_path, boolean append_value)
	{
		path = file_path;
		append_to_file = append_value;
	}
	
	public void writeToFile (String textLine) throws IOException
	{
		FileWriter write = new FileWriter (path, append_to_file);
		PrintWriter print_line = new PrintWriter (write);
		
		print_line.printf("%s" + "%n", textLine);
		
		print_line.close();
	}
	
//	public static void main (String[] args)
//	{
//		String file1 = "D:/All/Programming/Drone/Drone/test.txt";
//		try
//		{
//			WriteToFile data = new WriteToFile (file1, true);
//			data.writeToFile("Im a line of text");
//		}
//		catch (IOException e)
//		{
//			System.out.println(e.getMessage());
//		}
//	}

}
