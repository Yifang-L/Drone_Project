import java.util.ArrayList;

public class DefineObstacles {
	
	/**
	 * instance variables
	 */
	private ArrayList<Integer> xListExpd = null;
	private ArrayList<Integer> yListExpd = null;
	
	private ArrayList<ArrayList<Integer>> xObsListExpd = new ArrayList<ArrayList<Integer>>();
	private ArrayList<ArrayList<Integer>> yObsListExpd = new ArrayList<ArrayList<Integer>>();
	
	private ArrayList<Integer> xListExpdSorted = new ArrayList<Integer>();
	private ArrayList<Integer> yListExpdSorted = new ArrayList<Integer>();
	
	private ArrayList<Integer> xObsTagSorted = new ArrayList<Integer>();
	private ArrayList<Integer> yObsTagSorted = new ArrayList<Integer>();
	
	private ArrayList<Integer> xListExpdSortedNoRepetition = new ArrayList<Integer>();
	private ArrayList<Integer> yListExpdSortedNoRepetition = new ArrayList<Integer>();
	
	private ArrayList<Integer> xObsTagSortedNoRepetition = new ArrayList<Integer>();
	private ArrayList<Integer> yObsTagSortedNoRepetition = new ArrayList<Integer>();
	
	
	/**
	 * Getters
	 * @return instance variables
	 */
	public ArrayList<Integer> getXListExpd()
	{
		return xListExpd;
	}
	
	public ArrayList<Integer> getYListExpd()
	{
		return yListExpd;
	}
	
	public ArrayList<ArrayList<Integer>> getXObsListExpd ()
	{
		return xObsListExpd;
	}
	
	public ArrayList<ArrayList<Integer>> getYObsListExpd ()
	{
		return yObsListExpd;
	}
	
	public ArrayList<Integer> getXListSorted()
	{
		return xListExpdSorted;
	}
	
	public ArrayList<Integer> getYListSorted()
	{
		return yListExpdSorted;
	}
	
	public ArrayList<Integer> getXObsTagSorted()
	{
		return xObsTagSorted;
	}
	
	public ArrayList<Integer> getYObsTagSorted()
	{
		return yObsTagSorted;
	}
	
	public ArrayList<Integer> getXListSortedNoRepetition()
	{
		return xListExpdSortedNoRepetition;
	}
	
	public ArrayList<Integer> getYListSortedNoRepetition()
	{
		return yListExpdSortedNoRepetition;
	}
	
	public ArrayList<Integer>  getXObsTagSortedNoRepetition ()
	{
		return  xObsTagSortedNoRepetition ;
	}
	
	public ArrayList<Integer>  getYObsTagSortedNoRepetition ()
	{
		return  yObsTagSortedNoRepetition ;
	}
	
	/**
	 * Read x and y-coordinates of each obstacle from xObsList and yObsList
	 * Expand the size each obstacle by parameter d, which is 
	 * expend the length and width of each rectangle by parameter d
	 * Then store new x and y coordinates of each obstacle in xObsListExpd and yObsListExpd
	 * There are four cases when expand rectangles:
	 * 		Case 1: the rectangles are parallel
	 * 		Case 2: the rectangles are non-parallel, and the x-coordinates of first point 
	 * 			    and third point are equal, i.e. x0 = x2 	
	 * 		Case 3: the rectangles are non-parallel, and the x-coordinates of first point
	 * 				is less than the one of third point, i.e. x0 < x2
	 * 		Case 4: the rectangles are non-parallel, and the x-coordinates of first point
	 * 				is greater than the one of third point, i.e. x0 > x2
	 * @param xObsList stores lists of x-coordinates
	 * @param yObsList stores lists of y-coordinates
	 * @param d parameter d to expand the rectangles
	 */
	public void ExpandRectangle (ArrayList<ArrayList<Integer>> xObsList, ArrayList<ArrayList<Integer>> yObsList, int d)
	{		
    	int i = 0;
		while (i < xObsList.size())
		{
			xListExpd = new ArrayList<Integer>();
			yListExpd = new ArrayList<Integer>();
			
			//Case 1: parallel
			if (xObsList.get(i).get(1) == xObsList.get(i).get(2))
			{
				//point 1
				xListExpd.add(xObsList.get(i).get(0)+d);
				yListExpd.add(yObsList.get(i).get(0)-d);
				
				//point 2
				xListExpd.add(xObsList.get(i).get(1)-d);
				yListExpd.add(yObsList.get(i).get(1)-d);
				
				//point 3
				xListExpd.add(xObsList.get(i).get(2)-d);
				yListExpd.add(yObsList.get(i).get(2)+d);
				
				//point 4
				xListExpd.add(xObsList.get(i).get(3)+d);
				yListExpd.add(yObsList.get(i).get(3)+d);				
			}
			//Case 2: non-parallel, x0 == x2
			else if (xObsList.get(i).get(0) == xObsList.get(i).get(2))
			{
				d = (int)Math.sqrt(2) * d;
				//point 1
				xListExpd.add(xObsList.get(i).get(0));
				yListExpd.add(yObsList.get(i).get(0)-d);
				
				//point 2
				xListExpd.add(xObsList.get(i).get(1)-d);
				yListExpd.add(yObsList.get(i).get(1));
				
				//point 3
				xListExpd.add(xObsList.get(i).get(2));
				yListExpd.add(yObsList.get(i).get(2)+d);
				
				//point 4
				xListExpd.add(xObsList.get(i).get(3)+d);
				yListExpd.add(yObsList.get(i).get(3));				
			}
			//Case 3: non-parallel: x0 < x2
			else if (xObsList.get(i).get(2) > xObsList.get(i).get(0))
			{
				d = (int)Math.sqrt(2) * d;
				double a1, a2, a3, a4;
				double b1, b2, b3, b4;
				double c1, c2, c3, c4;
				
				//point 1
				c1 = (int)Math.sqrt(Math.pow((yObsList.get(i).get(1)-yObsList.get(i).get(0)),2)+Math.pow((xObsList.get(i).get(0)-xObsList.get(i).get(1)),2));
				a1 = ((yObsList.get(i).get(1)-yObsList.get(i).get(0)) + (xObsList.get(i).get(0)-xObsList.get(i).get(1)))/c1 * d;
				b1 = ((yObsList.get(i).get(1)-yObsList.get(i).get(0)) - (xObsList.get(i).get(0)-xObsList.get(i).get(1)))/c1 * d;
				xListExpd.add((int)(xObsList.get(i).get(0)-b1));
				yListExpd.add((int)(yObsList.get(i).get(0)-a1));
				
				//point 2
				c2 = (int)Math.sqrt(Math.pow((yObsList.get(i).get(2)-yObsList.get(i).get(1)),2)+Math.pow((xObsList.get(i).get(2)-xObsList.get(i).get(1)),2));
				a2 = ((xObsList.get(i).get(2)-xObsList.get(i).get(1)) + (yObsList.get(i).get(2)-yObsList.get(i).get(1)))/c2 * d;
				b2 = ((xObsList.get(i).get(2)-xObsList.get(i).get(1)) - (yObsList.get(i).get(2)-yObsList.get(i).get(1)))/c2 * d;
				xListExpd.add((int)(xObsList.get(i).get(1)-a2));
				yListExpd.add((int)(yObsList.get(i).get(1)+b2));
				
				//point 3
				c3 = (int)Math.sqrt(Math.pow((yObsList.get(i).get(2)-yObsList.get(i).get(3)),2)+Math.pow((xObsList.get(i).get(3)-xObsList.get(i).get(2)),2));
				a3 = ((yObsList.get(i).get(2)-yObsList.get(i).get(3)) + (xObsList.get(i).get(3)-xObsList.get(i).get(2)))/c3 * d;
				b3 = ((yObsList.get(i).get(2)-yObsList.get(i).get(3)) - (xObsList.get(i).get(3)-xObsList.get(i).get(2)))/c3 * d;
				xListExpd.add((int)(xObsList.get(i).get(2)+b3));
				yListExpd.add((int)(yObsList.get(i).get(2)+a3));
				
				//point 4
				c4 = (int)Math.sqrt(Math.pow((yObsList.get(i).get(3)-yObsList.get(i).get(0)),2)+Math.pow((xObsList.get(i).get(3)-xObsList.get(i).get(0)),2));
				a4 = ((xObsList.get(i).get(3)-xObsList.get(i).get(0)) + (yObsList.get(i).get(3)-yObsList.get(i).get(0)))/c4 * d;
				b4 = ((xObsList.get(i).get(3)-xObsList.get(i).get(0)) - (yObsList.get(i).get(3)-yObsList.get(i).get(0)))/c4 * d;
				xListExpd.add((int)(xObsList.get(i).get(3)+a4));
				yListExpd.add((int)(yObsList.get(i).get(3)-b4));
			}
			//Case 4: non-parallel: x0 > x2
			else if (xObsList.get(i).get(2)< xObsList.get(i).get(0))
			{
				d = (int)Math.sqrt(2) * d;
				double a1, a2, a3, a4;
				double b1, b2, b3, b4;
				double c1, c2, c3, c4;
			
				//point 1
				c1 = (int)Math.sqrt(Math.pow((yObsList.get(i).get(1)-yObsList.get(i).get(0)),2)+Math.pow((xObsList.get(i).get(0)-xObsList.get(i).get(1)),2));
				a1 = Math.abs(((yObsList.get(i).get(1)-yObsList.get(i).get(0)) + (xObsList.get(i).get(0)-xObsList.get(i).get(1))))/c1 * d;
				b1 = Math.abs(((yObsList.get(i).get(1)-yObsList.get(i).get(0)) - (xObsList.get(i).get(0)-xObsList.get(i).get(1))))/c1 * d;
				xListExpd.add((int)(xObsList.get(i).get(0)+b1));
				yListExpd.add((int)(yObsList.get(i).get(0)-a1));
				
				//point 2
				c2 = Math.sqrt(Math.pow((yObsList.get(i).get(2)-yObsList.get(i).get(1)),2)+Math.pow((xObsList.get(i).get(2)-xObsList.get(i).get(1)),2));
				a2 = Math.abs(((xObsList.get(i).get(2)-xObsList.get(i).get(1)) + (yObsList.get(i).get(2)-yObsList.get(i).get(1))))/c2 * d;
				b2 = Math.abs(((xObsList.get(i).get(2)-xObsList.get(i).get(1)) - (yObsList.get(i).get(2)-yObsList.get(i).get(1))))/c2 * d;
				xListExpd.add((int)(xObsList.get(i).get(1)-a2));
				yListExpd.add((int)(yObsList.get(i).get(1)-b2));
				
				//point 3
				c3 = (int)Math.sqrt(Math.pow((yObsList.get(i).get(2)-yObsList.get(i).get(3)),2)+Math.pow((xObsList.get(i).get(3)-xObsList.get(i).get(2)),2));
				a3 = Math.abs(((yObsList.get(i).get(2)-yObsList.get(i).get(3)) + (xObsList.get(i).get(3)-xObsList.get(i).get(2))))/c3 * d;
				b3 = Math.abs(((yObsList.get(i).get(2)-yObsList.get(i).get(3)) - (xObsList.get(i).get(3)-xObsList.get(i).get(2))))/c3 * d;
				xListExpd.add((int)(xObsList.get(i).get(2)-b3));
				yListExpd.add((int)(yObsList.get(i).get(2)+a3));
				
				//point 4
				c4 = (int)Math.sqrt(Math.pow((yObsList.get(i).get(3)-yObsList.get(i).get(0)),2)+Math.pow((xObsList.get(i).get(3)-xObsList.get(i).get(0)),2));
				a4 = Math.abs(((xObsList.get(i).get(3)-xObsList.get(i).get(0)) + (yObsList.get(i).get(3)-yObsList.get(i).get(0))))/c4 * d;
				b4 = Math.abs(((xObsList.get(i).get(3)-xObsList.get(i).get(0)) - (yObsList.get(i).get(3)-yObsList.get(i).get(0))))/c4 * d;
				xListExpd.add((int)(xObsList.get(i).get(3)+a4));
				yListExpd.add((int)(yObsList.get(i).get(3)+b4));
				
			}
			xObsListExpd.add(xListExpd);
			yObsListExpd.add(yListExpd);
			i++;
		}		
	}
	
	/**
	 * Sort the object list by the value of x
	 * @param xObsList stores xList
	 */
	public void SortingX (ArrayList<ArrayList<Integer>> xObsList)
	{
		for (int i = 0; i < xObsList.size(); i++)
		{
			for (int j = 0; j < xObsList.get(i).size(); j++)
			{
				if (xListExpdSorted.isEmpty())
				{
					xListExpdSorted.add(xObsList.get(i).get(j));
					xObsTagSorted.add(i);
					continue;
				}
				//sorting 
				int k = 0;
				while (k < xListExpdSorted.size())
				{
					
					if (xListExpdSorted.get(k) >= xObsList.get(i).get(j) )
					{
						xListExpdSorted.add(k, xObsList.get(i).get(j));
						xObsTagSorted.add(k, i);
						break;
					}
					else if (k == xListExpdSorted.size()-1) //k is the last element
					{
						xListExpdSorted.add(xObsList.get(i).get(j));
						xObsTagSorted.add(i);
						break;
					}
					else
					{
						k++;
					}
				}
			}
		}
	}
	
	/**
	 * Sort the object list by the value of y
	 * @param yObsList stores yList
	 */
	public void SortingY (ArrayList<ArrayList<Integer>> yObsList)
	{
		for (int i = 0; i < yObsList.size(); i++)
		{
			for (int j = 0; j < yObsList.get(i).size(); j++)
			{

				if (yListExpdSorted.isEmpty())
				{
					yListExpdSorted.add(yObsList.get(i).get(j));
					yObsTagSorted.add(i);
					continue;
				}
				//sorting 
				int k = 0;
				while (k < yListExpdSorted.size())
				{
					
					if (yListExpdSorted.get(k) >= yObsList.get(i).get(j) )
					{
						yListExpdSorted.add(k, yObsList.get(i).get(j));
						yObsTagSorted.add(k, i);
						break;
					}
					else if (k == yListExpdSorted.size()-1) //k is the last element
					{
						yListExpdSorted.add(yObsList.get(i).get(j));
						yObsTagSorted.add(i);
						break;
					}
					else
					{
						k++;
					}
				}
			}
		}
	}
	
	/**
	 * Remove the repetition from the sorted x-list
	 * @param xSortedList
	 */
	public void removeRepetitionX(ArrayList<Integer> xSortedList)
	{
		int j;
		xListExpdSortedNoRepetition.add(xSortedList.get(0));
		xObsTagSortedNoRepetition.add(xObsTagSorted.get(0));
		for(int i = 0; i < xSortedList.size()-1; i++)
		{
			j = i + 1;
			if( !xSortedList.get(i).equals(xSortedList.get(j)))
			{
				xListExpdSortedNoRepetition.add(xSortedList.get(j));	
				xObsTagSortedNoRepetition.add(xObsTagSorted.get(j));
			}			
		}
	}
	
	/**
	 * Remove the repetition from the sorted y-list
	 * @param ySortedList
	 */
	public void removeRepetitionY(ArrayList<Integer> ySortedList)
	{
		int j;
		yListExpdSortedNoRepetition.add(ySortedList.get(0));
		yObsTagSortedNoRepetition.add(yObsTagSorted.get(0));
		for(int i = 0; i < ySortedList.size()-1; i++)
		{
			j = i + 1;
			if( !ySortedList.get(i).equals(ySortedList.get(j)))
			{
				yListExpdSortedNoRepetition.add(ySortedList.get(j));	
				yObsTagSortedNoRepetition.add(yObsTagSorted.get(j));
			}			
		}
	}
	
	/**
	 * Add an element to the sorted arrayList if it doesn't contain this element
	 * return the index of value x
	 */
	public int addElementToSortedList (ArrayList<Integer> listSortedNoRepetition, ArrayList<Integer> tagList, int x)
	{
		for (int i = 0; i < listSortedNoRepetition.size(); i++)
		{
			if (listSortedNoRepetition.get(i) == x)
			{
				return i;
			}
			else if (listSortedNoRepetition.get(i) > x)
			{
				listSortedNoRepetition.add(i, x);
				tagList.add(i, -1);
				return i;
			}
		}
		listSortedNoRepetition.add(x);
		tagList.add(-1);
		return listSortedNoRepetition.size()-1;
	}
}
