import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class DisplayMap {

	/* Latitude and longitude of map */
	private double initialLat =  43.007979;
	private double initialLong = -81.274686;

	/*
	 * Coordinates are given as integer units. One integer unit corresponds to
	 * "scale" units on map. Make the value of "scale" larger if you want to
	 * draw bigger rectangles
	 */
	private double scale = 0.0000200;

	/*
	 * Radius of the circles used to mark starting position and destination.
	 * Change radius if you want to see larger of smaller markers for starting
	 * position and destination
	 */
	private int radius = 3;

	private BufferedWriter output;
	private String fileName;

	public DisplayMap(String outFile) {
		fileName = outFile;
		try {
			output = new BufferedWriter(new FileWriter(outFile));
		} catch (IOException e) {
			System.out.println("Error opening output file: " + outFile);
			System.exit(0);
		}
	}

	public DisplayMap(String outFile, double lat, double lng, double sc) {
		initialLat = lat;
		initialLong = lng;
		scale = sc;
		fileName = outFile;
		try {
			output = new BufferedWriter(new FileWriter(outFile));
		} catch (IOException e) {
			System.out.println("Error opening output file: " + outFile);
			System.exit(0);
		}
	}

	/*
	 * Write the HTML code needed to display map on a browser. Input is: (i) the
	 * coordinates of the starting point and the destination (ii) the
	 * coordinates of the vertices in the path from the starting point to the
	 * destination, (iii) the coordinates of the obstacles (x1,y1), (x2,y2),
	 * (x3,y3), (x4,y4).
	 */
	public void writeMap(int startx, int starty, int destx, int desty, int[] pathx, int[] pathy, int[] x1, int[] y1,
			int[] x2, int[] y2, int[] x3, int[] y3, int[] x4, int[] y4) {
		try {
			output.write("<!DOCTYPE html>\n");
			output.write("<html>\n");
			output.write("  <head> \n");
			output.write("    <title>Drone Map</title> \n");
			output.write("    <meta name=\"viewport\" content=\"initial-scale=1.0\"> \n");
			output.write("    <meta charset=\"utf-8\"> \n");
			output.write("    <style> \n");
			output.write("     #map {height: 100%;} \n");
			output.write("      html, body {height: 100%; margin: 0; padding: 0;} \n");
			output.write("    </style> \n");
			output.write("  </head> \n");
			output.write("  <body> \n");
			output.write("    <div id=\"map\"></div> \n");
			output.write("    <script> \n");
			output.write("      var map; \n");
			output.write("      function initMap() { \n");
			output.write("		var initial = {lat: " + initialLat + ", lng: " + (initialLong + 50 * scale) + "}; \n");
			output.write(
					"        map = new google.maps.Map(document.getElementById('map'), {center: initial,zoom: 15}); \n");

			output.write("		var mypath; \n");
			output.write("		var coords; \n");

			for (int i = 0; i < x1.length; ++i) {
				output.write("        coords = [\n");
				output.write("          {lat: " + (initialLat + y1[i] * scale) + ", lng: "
						+ (initialLong + x1[i] * scale) + "},\n");
				output.write("          {lat: " + (initialLat + y2[i] * scale) + ", lng: "
						+ (initialLong + x2[i] * scale) + "},\n");
				output.write("          {lat: " + (initialLat + y3[i] * scale) + ", lng: "
						+ (initialLong + x3[i] * scale) + "},\n");
				output.write("          {lat: " + (initialLat + y4[i] * scale) + ", lng: "
						+ (initialLong + x4[i] * scale) + "}\n");
				output.write("        ];\n");
				output.write(
						"	    mypath = new google.maps.Polygon({paths: coords, geodesic: true, strokeColor: '#FF0000', strokeOpacity: 1.0, strokeWeight: 2, fillOpacity: 0}); \n");
				output.write("		mypath.setMap(map);\n");
			}

			output.write("        coords = [\n");
			for (int i = 0; i < pathx.length; ++i)
				output.write("          {lat: " + (initialLat + pathy[i] * scale) + ", lng: "
						+ (initialLong + pathx[i] * scale) + "},\n");

			output.write("        ];\n");
			output.write(
					"      mypath = new google.maps.Polyline({path: coords, geodesic: true, strokeColor: '#0000FF', strokeOpacity: 1.0, strokeWeight: 2 });\n");
			output.write("	    mypath.setMap(map);\n");

			output.write(
					"var circ = new google.maps.Circle({ strokeColor: '#FF00FF', strokeWidth: 2, fillOpacity: 1, map: map, center: {lat: "
							+ (initialLat + starty * scale) + ", lng: " + (initialLong + startx * scale) + "}, radius: "
							+ radius + " });\n");
			output.write(
					"circ = new google.maps.Circle({ strokeColor: '#FF00FF', strokeWidth: 2, fillOpacity: 1, map: map, center: {lat: "
							+ (initialLat + desty * scale) + ", lng: " + (initialLong + destx * scale) + "}, radius: "
							+ radius + " });\n");
			output.write("	  } \n");
			output.write("    </script> \n");
			output.write(
					"    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyC12t-mPgRFCXJo9PtzkF1Sl-Mvi51FTyk&callback=initMap\"async defer> \n");
			output.write("  </script> \n");
			output.write(" </body> \n");
			output.write("</html> \n");
			output.close();
			System.out.println("HTML file " + fileName + " saved");
		} catch (

		IOException e) {
			System.out.println("Error writing to output file");
			System.exit(0);
		}
	}
	
	public void writeMapNoPath(int startx, int starty, int destx, int desty, int[] x1, int[] y1,
			int[] x2, int[] y2, int[] x3, int[] y3, int[] x4, int[] y4) {
		try {
			output.write("<!DOCTYPE html>\n");
			output.write("<html>\n");
			output.write("  <head> \n");
			output.write("    <title>Drone Map</title> \n");
			output.write("    <meta name=\"viewport\" content=\"initial-scale=1.0\"> \n");
			output.write("    <meta charset=\"utf-8\"> \n");
			output.write("    <style> \n");
			output.write("     #map {height: 100%;} \n");
			output.write("      html, body {height: 100%; margin: 0; padding: 0;} \n");
			output.write("    </style> \n");
			output.write("  </head> \n");
			output.write("  <body> \n");
			output.write("    <div id=\"map\"></div> \n");
			output.write("    <script> \n");
			output.write("      var map; \n");
			output.write("      function initMap() { \n");
			output.write("		var initial = {lat: " + initialLat + ", lng: " + (initialLong + 50 * scale) + "}; \n");
			output.write(
					"        map = new google.maps.Map(document.getElementById('map'), {center: initial,zoom: 15}); \n");

			output.write("		var mypath; \n");
			output.write("		var coords; \n");

			for (int i = 0; i < x1.length; ++i) {
				output.write("        coords = [\n");
				output.write("          {lat: " + (initialLat + y1[i] * scale) + ", lng: "
						+ (initialLong + x1[i] * scale) + "},\n");
				output.write("          {lat: " + (initialLat + y2[i] * scale) + ", lng: "
						+ (initialLong + x2[i] * scale) + "},\n");
				output.write("          {lat: " + (initialLat + y3[i] * scale) + ", lng: "
						+ (initialLong + x3[i] * scale) + "},\n");
				output.write("          {lat: " + (initialLat + y4[i] * scale) + ", lng: "
						+ (initialLong + x4[i] * scale) + "}\n");
				output.write("        ];\n");
				output.write(
						"	    mypath = new google.maps.Polygon({paths: coords, geodesic: true, strokeColor: '#FF0000', strokeOpacity: 1.0, strokeWeight: 2, fillOpacity: 0}); \n");
				output.write("		mypath.setMap(map);\n");
			}

			output.write("        coords = [\n");
//			for (int i = 0; i < pathx.length; ++i)
//				output.write("          {lat: " + (initialLat + pathy[i] * scale) + ", lng: "
//						+ (initialLong + pathx[i] * scale) + "},\n");

			output.write("        ];\n");
			output.write(
					"      mypath = new google.maps.Polyline({path: coords, geodesic: true, strokeColor: '#0000FF', strokeOpacity: 1.0, strokeWeight: 2 });\n");
			output.write("	    mypath.setMap(map);\n");

			output.write(
					"var circ = new google.maps.Circle({ strokeColor: '#FF00FF', strokeWidth: 2, fillOpacity: 1, map: map, center: {lat: "
							+ (initialLat + starty * scale) + ", lng: " + (initialLong + startx * scale) + "}, radius: "
							+ radius + " });\n");
			output.write(
					"circ = new google.maps.Circle({ strokeColor: '#FF00FF', strokeWidth: 2, fillOpacity: 1, map: map, center: {lat: "
							+ (initialLat + desty * scale) + ", lng: " + (initialLong + destx * scale) + "}, radius: "
							+ radius + " });\n");
			output.write("	  } \n");
			output.write("    </script> \n");
			output.write(
					"    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyC12t-mPgRFCXJo9PtzkF1Sl-Mvi51FTyk&callback=initMap\"async defer> \n");
			output.write("  </script> \n");
			output.write(" </body> \n");
			output.write("</html> \n");
			output.close();
			System.out.println("\nHTML file " + fileName + " saved");
		} catch (

		IOException e) {
			System.out.println("Error writing to output file");
			System.exit(0);
		}
	}
	
	
}
