import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * @author Yifang Liu
 * the format of the input.txt file
 * 1: starting point (x_start, y_start)
 * 2: destination point (x_destination, y_destination)
 * 3: width of the flying area
 * 4: length of the flying area
 * 5: parameter w (if cannot find the shortest path within the flying area, 
 *    need to expand w unit of distance)
 * 6: number of obstacles
 * 7: parameter d (the distance from the obstacles)
 * 8: the following: coordinates of obstacles (x1,y1,x2,y2,x3,y3,x4,y4)
 * 	 starting from the lower right corner or the lowest point of the rectangle, 
 * 	 find next point when moving in the clockwise direction 
 */
public class ReadInput {
	
	/**
	 * instance variables:
	 * x_s is the x-coordinate of starting point
	 * y_s is the y-coordinate of staring point
	 * x_d is the x-coordinate of destination point
	 * y_d is the y-coordinate of destination point
	 * width is the width of the flying area
	 * length is the length of the flying area
	 * w is parameter w (if cannot find the shortest path within the flying area,
	 *   need to expand w unit of distance)
	 * obsNum is the number of obstacles
	 * d is parameter d (the distance from the obstacles)
	 */
	private int lineNum;
	private int x_s;
    private int y_s;
    private int x_d;
    private int y_d;
    private int width;
    private int length;
    private int w;
    private int obsNum;
    private int d;
    
    //each xList stores four x-coordinates of one obstacle
    //each yList stores four y-coordinates of one obstacle
    private ArrayList<Integer> xList = null;
	private ArrayList<Integer> yList = null;
    
    //xObsList stores xList, which are the x-coordinates of all obstacles
	//yObsList stores yList, which are the y-coordinates of all obstacles
	//the size of xObsList and yObsList is the number of obstacles
	private ArrayList<ArrayList<Integer>> xObsList = new ArrayList<ArrayList<Integer>>();
    private ArrayList<ArrayList<Integer>> yObsList = new ArrayList<ArrayList<Integer>>();
    

	/**
	 * Setters and getters    
	 * @return the private instance variables
	 */
	public int getStartX()
	{
		return x_s;
	}
	
	public int getStartY()
	{
		return y_s;
	}
	
	public int getDestinationX()
	{
		return x_d;
	}
	
	public int getDestinationY()
	{
		return y_d;
	}
	
	public int getAreaWidth()
	{
		return width;
	}
	
	public int getAreaLength()
	{
		return length;
	}
	
	public int getParameterW()
	{
		return w;
	}
	
	public int getNumberOfObs()
	{
		return obsNum;
	}
	
	public int getParameterD()
	{
		return d;
	}
	
	public ArrayList<Integer> getXList()
	{
		return xList;
	}
	
	public ArrayList<Integer> getYList()
	{
		return yList;
	}
	
	public ArrayList<ArrayList<Integer>> getXObsList()
	{
		return xObsList;
	}
	
	public ArrayList<ArrayList<Integer>> getYObsList()
	{
		return yObsList;
	}
	
    
	/**
	 * Constructor
	 */
	public ReadInput(String fileName)
	{
        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fileName + ".txt");

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            switch(lineNum)
            {
	            case 0: //read starting point
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	x_s = Integer.parseInt(parts[0]);
	            	y_s = Integer.parseInt(parts[1]);
	            	//System.out.println("Starting point:\n(" + x_s + ","+ y_s + ")");
	            }
	            case 1: //read destination point
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	x_d = Integer.parseInt(parts[0]);
	            	y_d = Integer.parseInt(parts[1]);
	            	//System.out.println("Destination point:\n(" + x_d + ","+ y_d + ")");
	            }
	            case 2: //read the width 
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	width = Integer.parseInt(parts[0]);
	            	//System.out.println("The width of flying area:\n" + width);
	            }
	            case 3: //read the length
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	length = Integer.parseInt(parts[0]);
	            	//System.out.println("The length of flying area:\n" + length);
	            }
	            case 4:  //read the parameter w
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	w = Integer.parseInt(parts[0]);
	            	//System.out.println("The parameter w:\n" + w);
	            }
	            case 5: //read the number of obstacles
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	obsNum = Integer.parseInt(parts[0]);
	            	//System.out.println("The number of obstacles:\n" + obsNum);
	            }
	            case 6: //read the parameter d
	            {
	            	line = bufferedReader.readLine();
	            	String[] parts = line.split(",");
	            	d = Integer.parseInt(parts[0]);
	            	//System.out.println("The parameter d:\n" + d);
	            }
	            case 7: //read the coordinates of each obstacles
	            {	                
	            	while((line = bufferedReader.readLine()) != null) {
	            		xList =  new ArrayList<Integer>();
	            		yList =  new ArrayList<Integer>();
	                	String[] parts = line.split(",");

	                	 
	                	int x = 0, y = 0;
	                	for (int i = 0; i < parts.length; i++)
	                	{
	                		if (i%2 == 0)
	                		{
	                			//store x-coordinates of each obstacle in xList
	                			x = Integer.parseInt(parts[i]);
	                			xList.add(x);
	                		}
	                		else
	                		{
	                			//store y-coordinates of each obstacle in yList
	                			y = Integer.parseInt(parts[i]);
	                			yList.add(y);
	                		}	                	
	                	}
	                	
	                	//store each xList, yList in the xObsList, yObsList
		                xObsList.add(xList);
		                yObsList.add(yList);
	                } 	            	
	            }
            }
       
            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println("Sorry, the file '" + fileName + "' doesn't exist.\nPlease check it carefully and try again.\nGood bye!");  
            System.exit(0);
        }
        catch(IOException ex) {
            System.out.println("Sorry, there is an error reading the file '" + fileName + "'.\nPlease check it carefully and try again.\nGood bye!"); 
            System.exit(0);
        }
	}
}
