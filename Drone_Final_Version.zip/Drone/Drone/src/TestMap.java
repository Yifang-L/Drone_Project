
public class TestMap {

//	static int[] x1 = { 10, 50, 90 };
//	static int[] y1 = { 10, 10, 20 };
//	static int[] x2 = { 15, 54, 98 };
//	static int[] y2 = { 10, 10, 25 };
//	static int[] x3 = { 15, 54, 98 };
//	static int[] y3 = { 20, 25, 50 };
//	static int[] x4 = { 10, 50, 90 };
//	static int[] y4 = { 20, 25, 45 };
	static int[] pathx = { 1, 40, 50, 98, 110 };
	static int[] pathy = { 1, 10, 25, 50, 40 };

	static private double scale = 0.0000200;
	static private double initialLat =  43.007979;
	static private double initialLong = -81.274686;
    
    
	public static int transferX (double lon)
	{
		int x = (int) ((lon-initialLong)/scale);
		return x;
	}
	
	public static int transferY (double lat)
	{
		int y = (int)((lat-initialLat)/scale);
		return y;
	}
	
	public static void main(String[] args) {	
		

		int x_s = transferX(initialLong );
		int y_s =  transferY(initialLat);
		int x_d = transferX(-81.269729);
		int y_d = transferY(43.010042);
				
//		int[] x1 = {transferX(-81.273111)}; 
//		int[] y1 = {transferY(43.008101)};
//		int[] x2 = {transferX(-81.274439)};
//		int[] y2 = {transferY(43.008269)};
//		int[] x3 = {transferX(-81.274203)};
//		int[] y3 = {transferY(43.009285)};
//		int[] x4 = {transferX(-81.272798 )};
//		int[] y4 = {transferY(43.009132)};

	
		
		int[] x1 = {transferX(-81.270322)}; 
		int[] y1 = {transferY(43.008861)};
		int[] x2 = {transferX(-81.270301)};
		int[] y2 = {transferY(43.009241)};
		int[] x4 = {transferX(-81.270081)};
		int[] y4 = {transferY(43.008911)};
		int[] x3 = {transferX(-81.270011 )};
		int[] y3 = {transferY(43.009264)};
		//43.008890, -81.270126 43.008910, -81.270362 43.009318, -81.270346 43.009322, -81.269922
		
		System.out.println(x_s + "," + y_s);
		System.out.println(x_d + "," + y_d);
		System.out.println(x1[0] + "," + y1[0] + "," + x2[0] + "," + y2[0] + "," + x3[0] + "," + y3[0] + "," + x4[0] + "," + y4[0]);

		DisplayMap m = new DisplayMap("out2.html", initialLat, initialLong, scale);
		m.writeMapNoPath(x_s, y_s, x_d, y_d, x1, y1, x2, y2, x3, y3, x4, y4);
	}

}
